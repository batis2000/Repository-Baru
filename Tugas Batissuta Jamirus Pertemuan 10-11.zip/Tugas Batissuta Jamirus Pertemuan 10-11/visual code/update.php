<?php

include "../config/koneksi.php";

$Id = @$_POST['Id'];
$nama_barang = @$POST['nama_barang'];
$jumlah_barang = @$_POST['Jumlah_barang'];

$data = [];

$query = mysqli_query($kon, "UPDATE 'barang'  S
ET Nama_barang'='".$nama_barang ."' ,
'Jumlah_'='". $Jumlah_barang ."'
WHERE 'Id'". $Id ."'");

if($query){
    $status = true;
    $pesan = "request success";
    $data[] = $query;
}else{
    $status = false;
    $pesn = "request failed";
}

$json =[
    "status" => $status,
    "pesan" => $pesan,
    "data" => $data
];

header("Content-Type: application/json");
echo json_encode($json);

?>