<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "dabar";

$kon = mysqli_connect($host, $username, $password, $databas
e);
if (mysqli_connect_error()){
      echo "error connection ", mysqli_connect_error();
      exit();
}

?>