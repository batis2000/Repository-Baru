/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barang;

/**
 *
 * @author How Are You
 */
import java.sql.*;
import javax.swing.JOptionPane;

public class koneksi {

private static Connection databasekoneksi;
public static Connection koneksiDB() throws SQLException {
    if (databasekoneksi == null) {
        try {
            String DB = "jdbc:mysql://localhost:3306/data_barang";
            String user = "root";
            String pass = "";
            
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            databasekoneksi = (Connection) DriverManager.getConnection(DB,user,pass);
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "koneksi gagal");
        }
    } return databasekoneksi;
}
}
