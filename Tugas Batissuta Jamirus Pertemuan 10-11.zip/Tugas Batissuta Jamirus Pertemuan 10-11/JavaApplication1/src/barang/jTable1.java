/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barang;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author How Are You
 */
class jTable1 {

    static void setModel(DefaultTableModel tabMode) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
