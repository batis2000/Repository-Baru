package com.informatika.projectandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MaintLayout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maint_layout)
    }
}