Struktur project
dabar
---api
------create.php
------read.php
------update.php
------delete.php
------login.php
---config.php
------koneksi.php