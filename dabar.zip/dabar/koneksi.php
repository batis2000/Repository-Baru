<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "dabar";

$kon = mysql_connect($host, $username, $password, $database);
if(msqli_connect_erno()){
    echo "error connection ". msqli_connect_error();
    exit();
}

?>